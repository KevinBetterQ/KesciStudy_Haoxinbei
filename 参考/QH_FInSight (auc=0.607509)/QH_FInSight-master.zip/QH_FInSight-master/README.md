# QH_FInSight
前海征信“好信杯”大数据算法大赛  
天津大学FInSight团队作品  
线上AUC排名第七，算法方案排名第三  
有疑问请联系davidkangyz@163.com

